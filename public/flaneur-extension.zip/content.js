"use strict";
(() => {
  // extension/lib/messages.ts
  var UI_ATTR = "data-flaneur-ui";
  var CAPTURED_ATTR = "data-flaneur-captured";
  function hasKind(message, kind) {
    return typeof message === "object" && message !== null && "kind" in message && message.kind === kind;
  }
  var isPostMenuClicked = (message) => hasKind(message, "post-menu-clicked");

  // extension/lib/serialise.ts
  var REMOVED_TAGS = "script, style, noscript, svg, link, iframe";
  var TRACKING_PREFIXES = ["data-tracking", "data-analytics"];
  function isTracking(el) {
    return el.getAttributeNames().some((name) => TRACKING_PREFIXES.some((p) => name.startsWith(p)));
  }
  function isDecorative(el) {
    if (el.getAttribute("aria-hidden") !== "true") return false;
    if (el.tagName === "IMG" || el.querySelector("img")) return false;
    return (el.textContent ?? "").trim() === "";
  }
  function serialise(root) {
    const clone = root.cloneNode(true);
    if (!(clone instanceof Element)) throw new Error("serialise expects an element");
    for (const el of clone.querySelectorAll(REMOVED_TAGS)) el.remove();
    for (const el of clone.querySelectorAll(`[${UI_ATTR}]`)) el.remove();
    for (const el of clone.querySelectorAll("*")) {
      if (!clone.contains(el)) continue;
      if (isTracking(el) || isDecorative(el)) {
        el.remove();
        continue;
      }
      el.removeAttribute("class");
      el.removeAttribute("style");
      el.removeAttribute(CAPTURED_ATTR);
    }
    clone.removeAttribute("class");
    clone.removeAttribute("style");
    clone.removeAttribute(CAPTURED_ATTR);
    return clone.outerHTML;
  }

  // extension/lib/ui/host.ts
  var CSS = `
:host { all: initial; }
.stack { display: flex; flex-direction: column-reverse; align-items: flex-start; gap: 8px;
  font: 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; color: #1f1d1a; }
.panel { background: #fbfaf7; border: 1px solid #d9d4ca; border-radius: 10px;
  box-shadow: 0 6px 24px rgba(0,0,0,.14); }
.trigger { font: inherit; padding: 6px 12px; border-radius: 999px; cursor: pointer;
  background: #fbfaf7; border: 1px solid #d9d4ca; color: inherit; }
.trigger:hover { background: #f1eee7; }
.overlay { width: 280px; padding: 10px; display: flex; flex-direction: column; gap: 8px; }
.overlay header { display: flex; justify-content: space-between; align-items: center; font-weight: 600; }
.overlay textarea { font: inherit; resize: vertical; min-height: 54px; padding: 6px 8px;
  border: 1px solid #d9d4ca; border-radius: 6px; background: #fff; color: inherit; }
.row { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.status { color: #6b655c; }
.primary { font: inherit; padding: 5px 12px; border-radius: 6px; border: 0; cursor: pointer;
  background: #2f4a3a; color: #fff; }
.primary:disabled { opacity: .5; cursor: default; }
.close { font: inherit; background: none; border: 0; cursor: pointer; color: #6b655c; padding: 0 4px; }
.toast { padding: 8px 10px; display: flex; gap: 10px; align-items: center; }
.toast button { font: inherit; background: none; border: 0; color: #2f4a3a; cursor: pointer;
  text-decoration: underline; padding: 0; }
@media (prefers-color-scheme: dark) {
  .stack { color: #ece8e1; }
  .panel, .trigger { background: #26241f; border-color: #45413a; }
  .trigger:hover { background: #312e28; }
  .overlay textarea { background: #1c1a17; border-color: #45413a; }
  .status, .close { color: #a8a298; }
  .primary { background: #7fa68c; color: #14130f; }
  .toast button { color: #9fc4ab; }
}
`;
  var stack = null;
  function uiStack() {
    if (stack?.isConnected) return stack;
    const host = document.createElement("div");
    host.setAttribute(UI_ATTR, "");
    host.style.cssText = "position:fixed;left:16px;bottom:16px;z-index:2147483647;";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CSS;
    stack = document.createElement("div");
    stack.className = "stack";
    shadow.append(style, stack);
    document.body.append(host);
    return stack;
  }
  function h(tag, className, text) {
    const el = document.createElement(tag);
    el.className = className;
    if (text !== void 0) el.textContent = text;
    return el;
  }

  // extension/lib/ui/overlay.ts
  var CONFIRM_MS = 700;
  var isOpen = false;
  function isOverlayOpen() {
    return isOpen;
  }
  function openCaptureOverlay(options) {
    if (isOpen) return;
    isOpen = true;
    const form = h("form", "panel overlay");
    const header = h("header", "");
    const close = h("button", "close", "\xD7");
    close.type = "button";
    close.setAttribute("aria-label", "Cancel capture");
    header.append(h("span", "", options.heading), close);
    const textarea = h("textarea", "");
    textarea.placeholder = "why'd this catch your eye";
    textarea.setAttribute("aria-label", "Note");
    const status = h("span", "status");
    status.setAttribute("role", "status");
    const submit = h("button", "primary", "Capture");
    submit.type = "submit";
    const row = h("div", "row");
    row.append(status, submit);
    form.append(header, textarea, row);
    let settled = false;
    const dismiss = () => {
      form.remove();
      isOpen = false;
    };
    const cancel = () => {
      if (settled) return;
      settled = true;
      options.onCancel();
      dismiss();
    };
    close.addEventListener("click", cancel);
    form.addEventListener("keydown", (event) => {
      event.stopPropagation();
      if (event.key === "Escape") cancel();
      if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) form.requestSubmit();
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (settled) return;
      settled = true;
      submit.disabled = true;
      textarea.disabled = true;
      status.textContent = "Capturing\u2026";
      const note = textarea.value.trim();
      options.onSubmit(note === "" ? null : note).then(
        () => {
          status.textContent = "Captured";
          setTimeout(dismiss, CONFIRM_MS);
        },
        (error) => {
          settled = false;
          submit.disabled = false;
          textarea.disabled = false;
          status.textContent = error instanceof Error ? error.message : "Capture failed";
        }
      );
    });
    uiStack().append(form);
    textarea.focus();
  }

  // extension/lib/ui/toast.ts
  function showToast(text, action) {
    const toast = h("div", "panel toast");
    toast.setAttribute("role", "status");
    toast.append(h("span", "", text));
    if (action) {
      const button = h("button", "", action.label);
      button.type = "button";
      button.addEventListener("click", () => {
        toast.remove();
        action.run();
      });
      toast.append(button);
    }
    uiStack().append(toast);
    setTimeout(() => toast.remove(), action ? 8e3 : 2500);
  }

  // extension/lib/urn.ts
  var UPDATE_HREF = /\/feed\/update\/(urn:li:[A-Za-z]+:\d+)/;
  var COMMENT_KEY = /urn:li:comment:\((activity|ugcPost):(\d+),/;
  var ENCODED_ID = /^([A-Za-z0-9+/]+={0,2})-replaceableCommentTools/;
  function fromHref(container) {
    for (const a of container.querySelectorAll('a[href*="/feed/update/urn:li:"]')) {
      const match = UPDATE_HREF.exec(a.getAttribute("href") ?? "");
      if (match?.[1]) return match[1];
    }
    return null;
  }
  function fromCommentKey(container) {
    for (const el of container.querySelectorAll('[componentkey*="urn:li:comment:("]')) {
      const match = COMMENT_KEY.exec(el.getAttribute("componentkey") ?? "");
      if (match?.[1] && match[2]) return `urn:li:${match[1]}:${match[2]}`;
    }
    return null;
  }
  function readVarint(bytes, start) {
    let value = 0n;
    let shift = 0n;
    for (let i = start; i < bytes.length && shift < 70n; i++) {
      const byte = bytes[i];
      if (byte === void 0) return null;
      value |= BigInt(byte & 127) << shift;
      if ((byte & 128) === 0) return value;
      shift += 7n;
    }
    return null;
  }
  function decodeActivityId(encoded) {
    let bytes;
    try {
      bytes = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
    } catch {
      return null;
    }
    if (bytes[0] !== 10 || bytes[2] !== 8) return null;
    const raw = readVarint(bytes, 3);
    if (raw === null) return null;
    const id = raw >> 1n ^ -(raw & 1n);
    return id > 0n ? id.toString() : null;
  }
  function fromEncodedId(container) {
    for (const el of container.querySelectorAll('[id*="-replaceableCommentTools"]')) {
      const match = ENCODED_ID.exec(el.id);
      const id = match?.[1] ? decodeActivityId(match[1]) : null;
      if (id) return `urn:li:activity:${id}`;
    }
    return null;
  }
  function findPostUrn(container) {
    return fromHref(container) ?? fromCommentKey(container) ?? fromEncodedId(container);
  }

  // extension/content/deliver.ts
  var extensionVersion = () => chrome.runtime.getManifest().version;
  async function deliver(payload, onSettled) {
    const request = { kind: "capture", payload };
    let result;
    try {
      result = await chrome.runtime.sendMessage(request);
    } catch {
      result = { ok: false, error: "extension was reloaded, refresh the page" };
    }
    onSettled?.(result.ok);
    if (result.ok && result.summary) showToast(result.summary);
    if (!result.ok) {
      showToast(`Couldn't save capture (${result.error})`, {
        label: "Retry",
        run: () => void deliver(payload, onSettled)
      });
    }
  }

  // extension/content/post.ts
  var POST_SELECTOR = '[role="listitem"][componentkey^="update-card-focus"]';
  var lastTarget = null;
  var handledKeys = /* @__PURE__ */ new Set();
  function release(container, key) {
    container.removeAttribute(CAPTURED_ATTR);
    handledKeys.delete(key);
  }
  function captureAt(target) {
    if (isOverlayOpen()) return;
    const container = target?.closest(POST_SELECTOR) ?? null;
    if (!container) {
      showToast("Right-click inside a post to capture it");
      return;
    }
    const urn = findPostUrn(container);
    const key = urn ?? container.getAttribute("componentkey") ?? "";
    if (container.hasAttribute(CAPTURED_ATTR) || handledKeys.has(key)) {
      showToast("Already captured");
      return;
    }
    container.setAttribute(CAPTURED_ATTR, "pending");
    handledKeys.add(key);
    const html = serialise(container);
    const sourceUrl = location.href;
    openCaptureOverlay({
      heading: "Capture post",
      onCancel: () => release(container, key),
      onSubmit: async (note) => {
        const payload = { type: "post", sourceUrl, html, note, urn, extensionVersion: extensionVersion() };
        void deliver(payload, (ok) => {
          if (ok) container.setAttribute(CAPTURED_ATTR, "done");
          else release(container, key);
        });
      }
    });
  }
  function initPostCapture() {
    document.addEventListener(
      "contextmenu",
      (event) => {
        const origin = event.composedPath()[0];
        lastTarget = origin instanceof Element ? origin : null;
      },
      { capture: true }
    );
    chrome.runtime.onMessage.addListener((message) => {
      if (isPostMenuClicked(message)) captureAt(lastTarget);
      return false;
    });
  }

  // extension/lib/scroll.ts
  var MAX_STEPS = 80;
  var pause = (signal) => new Promise((resolve) => {
    const timer = setTimeout(resolve, 300 + Math.random() * 300);
    signal.addEventListener("abort", () => {
      clearTimeout(timer);
      resolve();
    });
  });
  function scrollContainer() {
    const main = document.querySelector("main#workspace");
    if (main && main.scrollHeight > main.clientHeight + 1) {
      const overflow = getComputedStyle(main).overflowY;
      if (overflow === "auto" || overflow === "scroll") return main;
    }
    return document.scrollingElement ?? document.documentElement;
  }
  async function scrollThrough(signal) {
    const el = scrollContainer();
    let lastHeight = -1;
    for (let step = 0; step < MAX_STEPS && !signal.aborted; step++) {
      el.scrollBy({ top: el.clientHeight * 0.8 });
      await pause(signal);
      const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 2;
      if (atBottom && el.scrollHeight === lastHeight) break;
      lastHeight = el.scrollHeight;
    }
    el.scrollTo({ top: 0 });
  }

  // extension/lib/ui/trigger.ts
  function mountTrigger(label, onClick) {
    const button = h("button", "trigger", label);
    button.type = "button";
    button.addEventListener("click", onClick);
    uiStack().prepend(button);
    return () => button.remove();
  }

  // extension/content/profile.ts
  var PROFILE_PATH = /^\/in\/[^/]+/;
  var ROUTE_POLL_MS = 1e3;
  function findProfileRoot() {
    return document.querySelector('main#workspace section[aria-label="Primary content"]') ?? document.querySelector("main#workspace") ?? document.querySelector("main");
  }
  function startCapture() {
    if (isOverlayOpen()) return;
    const scrolling = new AbortController();
    const scrolled = scrollThrough(scrolling.signal);
    openCaptureOverlay({
      heading: "Capture profile",
      onCancel: () => scrolling.abort(),
      onSubmit: async (note) => {
        await scrolled;
        const root = findProfileRoot();
        if (!root) throw new Error("Couldn't find the profile content");
        void deliver({
          type: "profile",
          sourceUrl: location.origin + location.pathname,
          html: serialise(root),
          note,
          urn: null,
          extensionVersion: extensionVersion()
        });
      }
    });
  }
  function initProfileCapture() {
    let unmount = null;
    const sync = () => {
      const onProfile = PROFILE_PATH.test(location.pathname);
      if (onProfile && !unmount) unmount = mountTrigger("Capture", startCapture);
      if (!onProfile && unmount) {
        unmount();
        unmount = null;
      }
    };
    sync();
    setInterval(sync, ROUTE_POLL_MS);
  }

  // extension/content/index.ts
  initProfileCapture();
  initPostCapture();
})();
