// extension/config.ts
var CAPTURE_SECRET = "ccf84f8a3b4e27e56059323291c6c509a3692bd3803f211c6bf571d6f7fa98ff";
var APP_URL = "https://flaneur-seven.vercel.app";

// extension/lib/messages.ts
var POST_MENU_ID = "flaneur-capture-post";
function hasKind(message, kind) {
  return typeof message === "object" && message !== null && "kind" in message && message.kind === kind;
}
var isCaptureRequest = (message) => hasKind(message, "capture");

// extension/background.ts
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: POST_MENU_ID,
    title: "Capture this post to Flaneur",
    contexts: ["all"],
    documentUrlPatterns: ["https://www.linkedin.com/*"]
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== POST_MENU_ID || tab?.id === void 0) return;
  const message = { kind: "post-menu-clicked" };
  chrome.tabs.sendMessage(tab.id, message, { frameId: info.frameId }).catch(() => {
  });
});
async function send(payload) {
  try {
    const response = await fetch(new URL("/api/capture", APP_URL), {
      method: "POST",
      headers: { "content-type": "application/json", "x-capture-secret": CAPTURE_SECRET },
      body: JSON.stringify(payload)
    });
    if (!response.ok) return { ok: false, error: `HTTP ${response.status}` };
    const body = await response.json().catch(() => null);
    const summary = typeof body === "object" && body !== null && "summary" in body && typeof body.summary === "string" ? body.summary : null;
    return { ok: true, summary };
  } catch {
    return { ok: false, error: "network error" };
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!isCaptureRequest(message)) return false;
  void send(message.payload).then(sendResponse);
  return true;
});
